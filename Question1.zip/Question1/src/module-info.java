/**
 * 
 */
/**
 * @author niet
 *
 */
module Question1 {
}